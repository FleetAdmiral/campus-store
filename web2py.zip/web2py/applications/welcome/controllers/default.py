# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################
from gluon.tools import Mail
mail = Mail()

mail = auth.settings.mailer
mail.settings.server = 'smtp@gmail.com:465'
mail.settings.sender = 'sampleemail@gmail.com'
mail.settings.login = 'sampleemail@gmail.com:password123'

def index():
  #  response.flash = T("Hello World")
    message=T('Store Portal')
    return locals()


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)

@auth.requires_login()
def sell():
    form=SQLFORM(db.item).process(next=URL('index'))
    return dict(form=form)
@auth.requires_login()
def redirect_email():
    show_item=db.item(request.args(0,cast=int)) or redirect(URL('index'))
    mail.send(to=['pranavnair97@gmail.com'],
         subject='Someone is interested in your item! [IIIT-Campus Store]',
         # If reply_to is omitted, then mail.settings.sender is used
         #reply_to=[auth_user1.email],
         message='Please do look into the matter! Regards , IIIT-Campus Store team.')
    
    return dict(item=show_item)
@auth.requires_login()
def item_buy():
    show_item=db.item(request.args(0,cast=int)) or redirect(URL('index'))
    return dict(item=show_item)
@auth.requires_login()
def buy():
    table=SQLFORM.grid(db.item,csv = False)
    items=db(db.item.id > 0).select(db.item.ALL,orderby=~db.item.id)
    return locals()
@auth.requires_login()
def item_show():
    show_item=db.item(request.args(0,cast=int)) or redirect(URL('index'))
    return dict(item=show_item)
@auth.requires_login()
def show():
    page=db.item(request.args(0,cast=int)) or redirect(URL('buy'))
    return locals()

def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
