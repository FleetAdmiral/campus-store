from gluon import *
categ=('Vehicle','Smartphones/Tablets','Books','Furniture')
