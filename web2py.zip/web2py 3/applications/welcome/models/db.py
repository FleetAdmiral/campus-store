db=DAL('sqlite://storage.sqlite')
from applications.welcome.modules.categories import *
from gluon.tools import *
auth=Auth(db)
auth.define_tables()
crud = Crud(db)

db.define_table('item',
                Field('name'),
                Field('body','text'),
                Field('listed_by','reference auth_user',default=auth.user_id),
                Field('category'),
                Field('image','upload'),
                Field('price','integer'),
)
db.define_table('comment',
                Field('comment_body','text'),
                Field('item_point','reference item'),
                Field('created_by','reference auth_user',default=auth.user_id),
                Field('created_on','datetime',default=request.now))
db.item.name.requires=IS_NOT_IN_DB(db, 'item.name')
db.item.body.requires=IS_NOT_EMPTY()
db.item.listed_by.readable=db.item.listed_by.writable=False
db.comment.comment_body.requires=IS_NOT_EMPTY()
db.comment.item_point.readable=db.comment.item_id=False
db.comment.created_by.readable=db.comment.created_by.writable=db.comment.created_on.readable=db.comment.created_on.writable=False
db.item.category.requires=IS_IN_SET(categ)
db.item.price.requires=IS_INT_IN_RANGE(0,1000000)
